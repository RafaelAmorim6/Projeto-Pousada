﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Pousada.Model
{
    class VerificaLogin
    {
        private string tempUser;
        private string tempSenha;
        private SqlConnection con;
        private SqlCommand query;
        private bool status;
        private string mensagem;

        public bool TratamentoLogin(String usuario, String senha)
        {
            tempUser = usuario;
            tempSenha = senha;

            con = new SqlConnection(@"data source=battlestation;initial catalog=DbPousada;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");

            if (tempUser == "" || tempSenha == "")
            {
                mensagem = "Insira seus dados de login corretamente";
                status = false;
            }
            else
            {
                try
                {
                    con.Open();
                    query = new SqlCommand("SELECT * FROM Funcionario WHERE nome_usu_func='" + usuario + "'AND senha_func='" + senha + "'", con);

                    SqlDataReader sdr = query.ExecuteReader();
                    if (sdr.Read() == true)
                    {
                        status = true;
                    }
                    else
                    {
                        mensagem = "Login Inválido";
                        status = false;
                    }
                }
                catch (Exception e)
                {
                    mensagem = "Erro ao efetuar login" + e.Message;
                }
            }
            return status;
        }
    }
}