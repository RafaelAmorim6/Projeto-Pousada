﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pousada.Controller
{
    class ConsultaFuncionarioController
    {
        private bool statuses;
        public bool CadastraFuncionario()
        {
            if(statuses == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
