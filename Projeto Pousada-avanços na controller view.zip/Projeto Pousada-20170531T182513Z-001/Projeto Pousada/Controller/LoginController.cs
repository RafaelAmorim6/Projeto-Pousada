﻿using Pousada.Model;
using Pousada.View;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pousada.Controller
{
    class LoginController
    {
        //xampson vars------------------
        VerificaLogin verif = new VerificaLogin();
        MenuPrincipal mainMenu = new MenuPrincipal();
        //------------------------------

        public bool TratarLogin(string user, string passwd)
        {
            bool status = false;
            status = verif.TratamentoLogin(user, passwd);

            if (status == false)
            {
                MessageBox.Show("Verifique os dados de login");
                return false;
            }
            else
            {
                return true;                
            }
        }
    }
}
