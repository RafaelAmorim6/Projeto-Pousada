﻿namespace Pousada.View
{
    partial class ConsultaQuartos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblConsultaClientes = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.lsbListaClientes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblConsultaClientes
            // 
            this.lblConsultaClientes.AutoSize = true;
            this.lblConsultaClientes.Location = new System.Drawing.Point(173, 18);
            this.lblConsultaClientes.Name = "lblConsultaClientes";
            this.lblConsultaClientes.Size = new System.Drawing.Size(103, 13);
            this.lblConsultaClientes.TabIndex = 7;
            this.lblConsultaClientes.Text = "Consulta de Quartos";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(294, 347);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 6;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnConsultar
            // 
            this.btnConsultar.Location = new System.Drawing.Point(95, 347);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(75, 23);
            this.btnConsultar.TabIndex = 5;
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.UseVisualStyleBackColor = true;
            // 
            // lsbListaClientes
            // 
            this.lsbListaClientes.FormattingEnabled = true;
            this.lsbListaClientes.Location = new System.Drawing.Point(24, 61);
            this.lsbListaClientes.Name = "lsbListaClientes";
            this.lsbListaClientes.Size = new System.Drawing.Size(429, 264);
            this.lsbListaClientes.TabIndex = 4;
            // 
            // ConsultaQuartos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 389);
            this.Controls.Add(this.lblConsultaClientes);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnConsultar);
            this.Controls.Add(this.lsbListaClientes);
            this.Name = "ConsultaQuartos";
            this.Text = "ConsultaQuartos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblConsultaClientes;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.ListBox lsbListaClientes;
    }
}