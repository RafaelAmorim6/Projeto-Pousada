﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pousada.Controller
{
    class ConsultaFuncionarioController
    {
        private bool statuses;
        //dados do cliente
        private string nome;
        private string telefone;
        private string email;
        private string usuario;
        private string senha;
        private string dataNasc;
        private bool isGerente;
        //---------------
        public bool CadastraFuncionario(string nomeTemp, string telefoneTemp, string emailTemp, string usuarioTemp, string senhaTemp, string dataNascTemp, bool gerenteTemp)
        {
          nome = nomeTemp;
          telefone = telefoneTemp;
          email = emailTemp;
          usuario = usuarioTemp;
          senha = senhaTemp;
          dataNasc = dataNascTemp;
          isGerente = gerenteTemp;


            if (statuses == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
