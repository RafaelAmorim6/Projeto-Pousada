﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pousada.View;
using System.Windows.Forms;

namespace Pousada.Controller
{
    class MainController
    {
        TelaLogin login = new TelaLogin();
        MenuPrincipal menuScr = new MenuPrincipal();
        CadastroFuncionario consFuncScr = new CadastroFuncionario();
        CadastroCliente cadCliScr = new CadastroCliente();
        ConsultaFuncionario cadFuncScr = new ConsultaFuncionario();
        private bool status = false; //status recebido do login
        private string usuarioLogado; //username do usuário logado
        private int telaMenu;//escolha do menu na tela do menu - shitch case

        public void IniciaSistema()
        {
            do
            {
                login.ShowDialog();
                status = login.statusLogin();
                if(status==true)
                {
                    usuarioLogado = login.Usuario.ToString();
                }

            } while (status == false);
            
            if (status==true)
            {
                ChamadaMenu();
            }
        }

        public void ChamadaMenu()
        {
            do
            {
                menuScr.ShowDialog();
                telaMenu = menuScr.ChosenOpt();
                switch (telaMenu)//shitch case huehuehue
                {
                    case 1: //botão Consultar funcionário = 1
                        TelaWorkers();
                        break;

                    case 2://botão cadastrar cliente = 2
                        break;

                    case 3://Cadastra quarto = 3
                        break;

                    case 4://cadastro reserva = 4
                        break;

                    case 5:// Consulta clientes cliente = 5
                        break;

                    case 6://consulta quartos = 6
                        break;

                    case 0://logout
                        break;

                    default:
                        MessageBox.Show("FODEU D++++++++");
                        break;

                }

            } while (telaMenu != 0);
            

        }

        public void TelaWorkers()
        {
            cadFuncScr.ShowDialog();
        }


    }
}
