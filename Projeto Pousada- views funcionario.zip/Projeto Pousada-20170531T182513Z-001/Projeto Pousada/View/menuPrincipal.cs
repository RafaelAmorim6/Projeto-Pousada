﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pousada.View
{
    public partial class MenuPrincipal : Form
    {
        private int telaEscolhida;
        public int TelaEscolhida { get => telaEscolhida; set => telaEscolhida = value; }
        public MenuPrincipal()
        {
            InitializeComponent();
        }

        private void btnConsultarFuncionarios_Click(object sender, EventArgs e)
        {
            //botão Consultar funcionário = 1
            telaEscolhida = 1;
            Close();
        }
        
        private void btnCadCliente_Click(object sender, EventArgs e)
        {
            //botão cadastrar cliente = 2
            telaEscolhida = 2;
            Close();
        }

        private void btnCadastraQuarto_Click(object sender, EventArgs e)
        {
            //Cadastra quarto = 3
            telaEscolhida = 3;
            Close();
        }

        private void btnCadastroReserva_Click(object sender, EventArgs e)
        {
            //cadastro reserva = 4
            telaEscolhida = 4;
            Close();
        }

        private void btnConsultaCliente_Click(object sender, EventArgs e)
        {
            // Consulta clientes cliente = 5 
            telaEscolhida = 5;
            Close();
        }

        private void btnConsultarQuartos_Click(object sender, EventArgs e)
        {
            //consulta quartos = 6
            telaEscolhida = 6;
            Close();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            //logout
            telaEscolhida = 0;
            Close();
        }
        public int ChosenOpt()
        {
            return telaEscolhida;
        }

        
    }
}
