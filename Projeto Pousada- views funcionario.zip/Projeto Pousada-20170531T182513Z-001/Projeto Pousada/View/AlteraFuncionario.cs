﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pousada.View
{
    public partial class AlteraFuncionario : Form
    {
        private string codigoFunc;
        public AlteraFuncionario(string codigo, string nomeTemp, string telefoneTemp, string emailTemp, string usuarioTemp, string senhaTemp, string dataNascTemp, string gerenteTemp)
        {
            InitializeComponent();
            codigoFunc = codigo;
            txbNome.Text = nomeTemp;
            mtbTelefone.Text = telefoneTemp;
            mtbEmail.Text = emailTemp;
            txbUsuario.Text = usuarioTemp;
            mtbSenha.Text = senhaTemp;
            mtbData.Text = dataNascTemp;

            if (gerenteTemp == "true")
            {
                ckbGerente.Checked = true;
            }
            else
            {
                ckbGerente.Checked = false;
            }
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
