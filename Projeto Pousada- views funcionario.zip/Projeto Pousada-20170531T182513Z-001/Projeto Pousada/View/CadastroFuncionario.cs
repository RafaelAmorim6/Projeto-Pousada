﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pousada.Controller;

namespace Pousada.View
{
    public partial class CadastroFuncionario : Form
    {
        private bool status;
        public CadastroFuncionario()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            ConsultaFuncionarioController objCad = new ConsultaFuncionarioController();
                        
            status = objCad.CadastraFuncionario(txbNome.Text, mtbTelefone.Text, mtbEmail.Text, txbUsuario.Text, mtbSenha.Text, mtbData.Text, ckbGerente.Checked);


           
            if (status == true)
            {
                MessageBox.Show("Cadastro Efetuado com sucesso!");
                Close();
            }
            else
            {
                MessageBox.Show("Erro! Cadastro não efetuado. Verifique os dados");
                Close();
            }

        }
    }
}
