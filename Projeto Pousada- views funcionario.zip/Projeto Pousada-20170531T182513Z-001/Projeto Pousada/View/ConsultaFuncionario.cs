﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ComponentModel.DataAnnotations;


namespace Pousada.View
{
    public partial class ConsultaFuncionario : Form
    {
        public ConsultaFuncionario()
        {
            InitializeComponent();
        }

        private void ConsultaFuncionario_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dbPousadaDataSet.Funcionario' table. You can move, or remove it, as needed.
            this.funcionarioTableAdapter.Fill(this.dbPousadaDataSet.Funcionario);

        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            //botao cadastrar
            CadastroFuncionario cadfunc = new CadastroFuncionario();
            cadfunc.ShowDialog();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            //botao cancelar
            Close();
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            string codigoCliente = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            string nome = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            string dataNasc = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            string telefone = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            string email = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            string usuario = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            string senha = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            string isGerente = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();

            AlteraFuncionario alterar = new AlteraFuncionario(codigoCliente, nome, telefone, email, usuario, senha, dataNasc, isGerente);

            alterar.ShowDialog();
        }
    }
}
