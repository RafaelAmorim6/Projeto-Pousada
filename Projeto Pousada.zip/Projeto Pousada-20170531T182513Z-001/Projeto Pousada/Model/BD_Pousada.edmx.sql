
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 06/10/2017 22:12:07
-- Generated from EDMX file: C:\Users\Rafae\Desktop\Projeto Pousada\Projeto Pousada-20170531T182513Z-001\Projeto Pousada\Model\BD_Pousada.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [DbPousada];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_ClienteReserva]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Reserva] DROP CONSTRAINT [FK_ClienteReserva];
GO
IF OBJECT_ID(N'[dbo].[FK_Forma_PagamentoReserva]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Reserva] DROP CONSTRAINT [FK_Forma_PagamentoReserva];
GO
IF OBJECT_ID(N'[dbo].[FK_FuncionarioLogin]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Login] DROP CONSTRAINT [FK_FuncionarioLogin];
GO
IF OBJECT_ID(N'[dbo].[FK_FuncionarioReserva]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Reserva] DROP CONSTRAINT [FK_FuncionarioReserva];
GO
IF OBJECT_ID(N'[dbo].[FK_QuartoReserva]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Reserva] DROP CONSTRAINT [FK_QuartoReserva];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Cliente]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Cliente];
GO
IF OBJECT_ID(N'[dbo].[Forma_Pagamento]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Forma_Pagamento];
GO
IF OBJECT_ID(N'[dbo].[Funcionario]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Funcionario];
GO
IF OBJECT_ID(N'[dbo].[Login]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Login];
GO
IF OBJECT_ID(N'[dbo].[Quarto]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Quarto];
GO
IF OBJECT_ID(N'[dbo].[Reserva]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Reserva];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Funcionario'
CREATE TABLE [dbo].[Funcionario] (
    [id_func] int IDENTITY(1,1) NOT NULL,
    [nome_func] nvarchar(100)  NOT NULL,
    [data_nasc_func] datetime  NOT NULL,
    [telefone_func] nvarchar(14)  NOT NULL,
    [email_func] nvarchar(max)  NOT NULL,
    [nome_usu_func] nvarchar(15)  NOT NULL,
    [senha_func] nvarchar(8)  NOT NULL,
    [is_gerente] bit  NOT NULL
);
GO

-- Creating table 'Cliente'
CREATE TABLE [dbo].[Cliente] (
    [id_cli] int IDENTITY(1,1) NOT NULL,
    [nome_cli] nvarchar(100)  NOT NULL,
    [data_nasc_cli] datetime  NOT NULL,
    [cpf_cli] nvarchar(14)  NOT NULL,
    [rua_cli] nvarchar(50)  NOT NULL,
    [bairro_cli] nvarchar(20)  NOT NULL,
    [cep_cli] nvarchar(9)  NOT NULL,
    [cidade_cli] nvarchar(40)  NOT NULL,
    [estado_cli] nvarchar(25)  NOT NULL,
    [telefone_cli] nvarchar(14)  NOT NULL,
    [email_cli] nvarchar(100)  NOT NULL
);
GO

-- Creating table 'Quarto'
CREATE TABLE [dbo].[Quarto] (
    [id_quarto] int IDENTITY(1,1) NOT NULL,
    [num_quarto] nvarchar(max)  NOT NULL,
    [capacidade] int  NOT NULL,
    [is_frigobar] bit  NOT NULL,
    [is_tv] bit  NOT NULL,
    [is_wifi] bit  NOT NULL
);
GO

-- Creating table 'Reserva'
CREATE TABLE [dbo].[Reserva] (
    [id_reserva] int IDENTITY(1,1) NOT NULL,
    [data_agendamento_reserva] nvarchar(max)  NOT NULL,
    [data_inicio] nvarchar(max)  NOT NULL,
    [data_fim] nvarchar(max)  NOT NULL,
    [comentarios_cliente] nvarchar(max)  NOT NULL,
    [observacoes_reserva] nvarchar(max)  NOT NULL,
    [id_func] int  NOT NULL,
    [id_cli] int  NOT NULL,
    [id_quarto] int  NOT NULL,
    [id_forma_pagamento] int  NOT NULL
);
GO

-- Creating table 'Forma_Pagamento'
CREATE TABLE [dbo].[Forma_Pagamento] (
    [id_forma_pagamento] int IDENTITY(1,1) NOT NULL,
    [descricao_forma_pagamento] nvarchar(20)  NOT NULL
);
GO

-- Creating table 'Login'
CREATE TABLE [dbo].[Login] (
    [id_login] int IDENTITY(1,1) NOT NULL,
    [data_hora_login] datetime  NOT NULL,
    [data_hora_logout] datetime  NOT NULL,
    [id_func] int  NOT NULL,
    [senha] nvarchar(max)  NOT NULL,
    [usuario] nvarchar(max)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [id_func] in table 'Funcionario'
ALTER TABLE [dbo].[Funcionario]
ADD CONSTRAINT [PK_Funcionario]
    PRIMARY KEY CLUSTERED ([id_func] ASC);
GO

-- Creating primary key on [id_cli] in table 'Cliente'
ALTER TABLE [dbo].[Cliente]
ADD CONSTRAINT [PK_Cliente]
    PRIMARY KEY CLUSTERED ([id_cli] ASC);
GO

-- Creating primary key on [id_quarto] in table 'Quarto'
ALTER TABLE [dbo].[Quarto]
ADD CONSTRAINT [PK_Quarto]
    PRIMARY KEY CLUSTERED ([id_quarto] ASC);
GO

-- Creating primary key on [id_reserva] in table 'Reserva'
ALTER TABLE [dbo].[Reserva]
ADD CONSTRAINT [PK_Reserva]
    PRIMARY KEY CLUSTERED ([id_reserva] ASC);
GO

-- Creating primary key on [id_forma_pagamento] in table 'Forma_Pagamento'
ALTER TABLE [dbo].[Forma_Pagamento]
ADD CONSTRAINT [PK_Forma_Pagamento]
    PRIMARY KEY CLUSTERED ([id_forma_pagamento] ASC);
GO

-- Creating primary key on [id_login] in table 'Login'
ALTER TABLE [dbo].[Login]
ADD CONSTRAINT [PK_Login]
    PRIMARY KEY CLUSTERED ([id_login] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [id_func] in table 'Reserva'
ALTER TABLE [dbo].[Reserva]
ADD CONSTRAINT [FK_FuncionarioReserva]
    FOREIGN KEY ([id_func])
    REFERENCES [dbo].[Funcionario]
        ([id_func])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FuncionarioReserva'
CREATE INDEX [IX_FK_FuncionarioReserva]
ON [dbo].[Reserva]
    ([id_func]);
GO

-- Creating foreign key on [id_cli] in table 'Reserva'
ALTER TABLE [dbo].[Reserva]
ADD CONSTRAINT [FK_ClienteReserva]
    FOREIGN KEY ([id_cli])
    REFERENCES [dbo].[Cliente]
        ([id_cli])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClienteReserva'
CREATE INDEX [IX_FK_ClienteReserva]
ON [dbo].[Reserva]
    ([id_cli]);
GO

-- Creating foreign key on [id_quarto] in table 'Reserva'
ALTER TABLE [dbo].[Reserva]
ADD CONSTRAINT [FK_QuartoReserva]
    FOREIGN KEY ([id_quarto])
    REFERENCES [dbo].[Quarto]
        ([id_quarto])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_QuartoReserva'
CREATE INDEX [IX_FK_QuartoReserva]
ON [dbo].[Reserva]
    ([id_quarto]);
GO

-- Creating foreign key on [id_forma_pagamento] in table 'Reserva'
ALTER TABLE [dbo].[Reserva]
ADD CONSTRAINT [FK_Forma_PagamentoReserva]
    FOREIGN KEY ([id_forma_pagamento])
    REFERENCES [dbo].[Forma_Pagamento]
        ([id_forma_pagamento])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Forma_PagamentoReserva'
CREATE INDEX [IX_FK_Forma_PagamentoReserva]
ON [dbo].[Reserva]
    ([id_forma_pagamento]);
GO

-- Creating foreign key on [id_func] in table 'Login'
ALTER TABLE [dbo].[Login]
ADD CONSTRAINT [FK_FuncionarioLogin]
    FOREIGN KEY ([id_func])
    REFERENCES [dbo].[Funcionario]
        ([id_func])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FuncionarioLogin'
CREATE INDEX [IX_FK_FuncionarioLogin]
ON [dbo].[Login]
    ([id_func]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------