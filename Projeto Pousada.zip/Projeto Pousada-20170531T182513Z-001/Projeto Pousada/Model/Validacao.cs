﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pousada.Model
{
        class Validacao
        {
            public static IEnumerable<ValidationResult> Valida(Object objeto)
            {
            // Cria uma lista para armazenar os erros encontrados nas validacaes de cada dado do objeto. 
            var erros = new List<ValidationResult>();
            // Cria o contexto que sera argumento do metodo TryValidateObject abaixo. 
            var contexto = new ValidationContext(objeto, null, null);
            // Chama o metodo TryValidateObject. 0 ultimo argumento deste metodo indica se todos 
            // os dados do objeto devem ser validados (true) ou se a validacao deve ser interrompida 
            // assim que o primeiro erro for encontrado (false). 
            Validator.TryValidateObject(objeto, contexto, erros, true);
            return erros; // Retorna a lista de erros encontrados. 
            }
        }
}
