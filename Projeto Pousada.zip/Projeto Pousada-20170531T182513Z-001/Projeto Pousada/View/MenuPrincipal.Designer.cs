﻿namespace Pousada.View
{
    partial class MenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMainMenu = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnCadCliente = new System.Windows.Forms.Button();
            this.btnConsultaCliente = new System.Windows.Forms.Button();
            this.btnCadastraQuarto = new System.Windows.Forms.Button();
            this.btnCadastroReserva = new System.Windows.Forms.Button();
            this.btnConsultarQuartos = new System.Windows.Forms.Button();
            this.btnConsultarFuncionarios = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMainMenu
            // 
            this.lblMainMenu.AutoSize = true;
            this.lblMainMenu.Location = new System.Drawing.Point(162, 23);
            this.lblMainMenu.Name = "lblMainMenu";
            this.lblMainMenu.Size = new System.Drawing.Size(77, 13);
            this.lblMainMenu.TabIndex = 0;
            this.lblMainMenu.Text = "Menu Principal";
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(164, 287);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 5;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            // 
            // btnCadCliente
            // 
            this.btnCadCliente.Location = new System.Drawing.Point(30, 82);
            this.btnCadCliente.Name = "btnCadCliente";
            this.btnCadCliente.Size = new System.Drawing.Size(137, 23);
            this.btnCadCliente.TabIndex = 6;
            this.btnCadCliente.Text = "Cadastro de Cliente";
            this.btnCadCliente.UseVisualStyleBackColor = true;
            // 
            // btnConsultaCliente
            // 
            this.btnConsultaCliente.Location = new System.Drawing.Point(234, 82);
            this.btnConsultaCliente.Name = "btnConsultaCliente";
            this.btnConsultaCliente.Size = new System.Drawing.Size(137, 23);
            this.btnConsultaCliente.TabIndex = 7;
            this.btnConsultaCliente.Text = "Consultar Clientes";
            this.btnConsultaCliente.UseVisualStyleBackColor = true;
            // 
            // btnCadastraQuarto
            // 
            this.btnCadastraQuarto.Location = new System.Drawing.Point(30, 111);
            this.btnCadastraQuarto.Name = "btnCadastraQuarto";
            this.btnCadastraQuarto.Size = new System.Drawing.Size(137, 23);
            this.btnCadastraQuarto.TabIndex = 8;
            this.btnCadastraQuarto.Text = "Cadastro de Quartos";
            this.btnCadastraQuarto.UseVisualStyleBackColor = true;
            // 
            // btnCadastroReserva
            // 
            this.btnCadastroReserva.Location = new System.Drawing.Point(30, 140);
            this.btnCadastroReserva.Name = "btnCadastroReserva";
            this.btnCadastroReserva.Size = new System.Drawing.Size(137, 23);
            this.btnCadastroReserva.TabIndex = 9;
            this.btnCadastroReserva.Text = "Cadastro de Reserva";
            this.btnCadastroReserva.UseVisualStyleBackColor = true;
            // 
            // btnConsultarQuartos
            // 
            this.btnConsultarQuartos.Location = new System.Drawing.Point(234, 111);
            this.btnConsultarQuartos.Name = "btnConsultarQuartos";
            this.btnConsultarQuartos.Size = new System.Drawing.Size(137, 23);
            this.btnConsultarQuartos.TabIndex = 10;
            this.btnConsultarQuartos.Text = "Consultar Quartos";
            this.btnConsultarQuartos.UseVisualStyleBackColor = true;
            // 
            // btnConsultarFuncionarios
            // 
            this.btnConsultarFuncionarios.Location = new System.Drawing.Point(234, 140);
            this.btnConsultarFuncionarios.Name = "btnConsultarFuncionarios";
            this.btnConsultarFuncionarios.Size = new System.Drawing.Size(137, 23);
            this.btnConsultarFuncionarios.TabIndex = 11;
            this.btnConsultarFuncionarios.Text = "Consultar Funcionários";
            this.btnConsultarFuncionarios.UseVisualStyleBackColor = true;
            // 
            // MenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 383);
            this.Controls.Add(this.btnConsultarFuncionarios);
            this.Controls.Add(this.btnConsultarQuartos);
            this.Controls.Add(this.btnCadastroReserva);
            this.Controls.Add(this.btnCadastraQuarto);
            this.Controls.Add(this.btnConsultaCliente);
            this.Controls.Add(this.btnCadCliente);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.lblMainMenu);
            this.Name = "MenuPrincipal";
            this.Text = "Sistema de Reservas - Pousada Pousadão";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMainMenu;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnCadCliente;
        private System.Windows.Forms.Button btnConsultaCliente;
        private System.Windows.Forms.Button btnCadastraQuarto;
        private System.Windows.Forms.Button btnCadastroReserva;
        private System.Windows.Forms.Button btnConsultarQuartos;
        private System.Windows.Forms.Button btnConsultarFuncionarios;
    }
}