﻿namespace Pousada.View
{
    partial class ConsultaFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblConsultaClientes = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dbPousadaDataSet = new Pousada.DbPousadaDataSet();
            this.funcionarioBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.funcionarioTableAdapter = new Pousada.DbPousadaDataSetTableAdapters.FuncionarioTableAdapter();
            this.idfuncDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomefuncDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datanascfuncDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonefuncDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailfuncDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomeusufuncDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.senhafuncDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isgerenteDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbPousadaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.funcionarioBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lblConsultaClientes
            // 
            this.lblConsultaClientes.AutoSize = true;
            this.lblConsultaClientes.Location = new System.Drawing.Point(175, 11);
            this.lblConsultaClientes.Name = "lblConsultaClientes";
            this.lblConsultaClientes.Size = new System.Drawing.Size(126, 13);
            this.lblConsultaClientes.TabIndex = 7;
            this.lblConsultaClientes.Text = "Consulta de Funcionários";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(296, 340);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 6;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnConsultar
            // 
            this.btnConsultar.Location = new System.Drawing.Point(97, 340);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(75, 23);
            this.btnConsultar.TabIndex = 5;
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idfuncDataGridViewTextBoxColumn,
            this.nomefuncDataGridViewTextBoxColumn,
            this.datanascfuncDataGridViewTextBoxColumn,
            this.telefonefuncDataGridViewTextBoxColumn,
            this.emailfuncDataGridViewTextBoxColumn,
            this.nomeusufuncDataGridViewTextBoxColumn,
            this.senhafuncDataGridViewTextBoxColumn,
            this.isgerenteDataGridViewCheckBoxColumn});
            this.dataGridView1.DataSource = this.funcionarioBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(37, 51);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(507, 150);
            this.dataGridView1.TabIndex = 8;
            // 
            // dbPousadaDataSet
            // 
            this.dbPousadaDataSet.DataSetName = "DbPousadaDataSet";
            this.dbPousadaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // funcionarioBindingSource
            // 
            this.funcionarioBindingSource.DataMember = "Funcionario";
            this.funcionarioBindingSource.DataSource = this.dbPousadaDataSet;
            // 
            // funcionarioTableAdapter
            // 
            this.funcionarioTableAdapter.ClearBeforeFill = true;
            // 
            // idfuncDataGridViewTextBoxColumn
            // 
            this.idfuncDataGridViewTextBoxColumn.DataPropertyName = "id_func";
            this.idfuncDataGridViewTextBoxColumn.HeaderText = "id_func";
            this.idfuncDataGridViewTextBoxColumn.Name = "idfuncDataGridViewTextBoxColumn";
            this.idfuncDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nomefuncDataGridViewTextBoxColumn
            // 
            this.nomefuncDataGridViewTextBoxColumn.DataPropertyName = "nome_func";
            this.nomefuncDataGridViewTextBoxColumn.HeaderText = "nome_func";
            this.nomefuncDataGridViewTextBoxColumn.Name = "nomefuncDataGridViewTextBoxColumn";
            // 
            // datanascfuncDataGridViewTextBoxColumn
            // 
            this.datanascfuncDataGridViewTextBoxColumn.DataPropertyName = "data_nasc_func";
            this.datanascfuncDataGridViewTextBoxColumn.HeaderText = "data_nasc_func";
            this.datanascfuncDataGridViewTextBoxColumn.Name = "datanascfuncDataGridViewTextBoxColumn";
            // 
            // telefonefuncDataGridViewTextBoxColumn
            // 
            this.telefonefuncDataGridViewTextBoxColumn.DataPropertyName = "telefone_func";
            this.telefonefuncDataGridViewTextBoxColumn.HeaderText = "telefone_func";
            this.telefonefuncDataGridViewTextBoxColumn.Name = "telefonefuncDataGridViewTextBoxColumn";
            // 
            // emailfuncDataGridViewTextBoxColumn
            // 
            this.emailfuncDataGridViewTextBoxColumn.DataPropertyName = "email_func";
            this.emailfuncDataGridViewTextBoxColumn.HeaderText = "email_func";
            this.emailfuncDataGridViewTextBoxColumn.Name = "emailfuncDataGridViewTextBoxColumn";
            // 
            // nomeusufuncDataGridViewTextBoxColumn
            // 
            this.nomeusufuncDataGridViewTextBoxColumn.DataPropertyName = "nome_usu_func";
            this.nomeusufuncDataGridViewTextBoxColumn.HeaderText = "nome_usu_func";
            this.nomeusufuncDataGridViewTextBoxColumn.Name = "nomeusufuncDataGridViewTextBoxColumn";
            // 
            // senhafuncDataGridViewTextBoxColumn
            // 
            this.senhafuncDataGridViewTextBoxColumn.DataPropertyName = "senha_func";
            this.senhafuncDataGridViewTextBoxColumn.HeaderText = "senha_func";
            this.senhafuncDataGridViewTextBoxColumn.Name = "senhafuncDataGridViewTextBoxColumn";
            // 
            // isgerenteDataGridViewCheckBoxColumn
            // 
            this.isgerenteDataGridViewCheckBoxColumn.DataPropertyName = "is_gerente";
            this.isgerenteDataGridViewCheckBoxColumn.HeaderText = "is_gerente";
            this.isgerenteDataGridViewCheckBoxColumn.Name = "isgerenteDataGridViewCheckBoxColumn";
            // 
            // ConsultaFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 374);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblConsultaClientes);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnConsultar);
            this.Name = "ConsultaFuncionario";
            this.Text = "ConsultaFuncionario";
            this.Load += new System.EventHandler(this.ConsultaFuncionario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbPousadaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.funcionarioBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblConsultaClientes;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DbPousadaDataSet dbPousadaDataSet;
        private System.Windows.Forms.BindingSource funcionarioBindingSource;
        private DbPousadaDataSetTableAdapters.FuncionarioTableAdapter funcionarioTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idfuncDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomefuncDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datanascfuncDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonefuncDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailfuncDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeusufuncDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn senhafuncDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isgerenteDataGridViewCheckBoxColumn;
    }
}