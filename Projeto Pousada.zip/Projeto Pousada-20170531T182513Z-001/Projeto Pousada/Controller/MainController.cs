﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pousada.View;
namespace Pousada.Controller
{
    class MainController
    {
        TelaLogin login = new TelaLogin();
        MenuPrincipal menuScr = new MenuPrincipal();
        CadastroFuncionario cadFuncScr = new CadastroFuncionario();
        CadastroCliente cadCliScr = new CadastroCliente();


    }
}
