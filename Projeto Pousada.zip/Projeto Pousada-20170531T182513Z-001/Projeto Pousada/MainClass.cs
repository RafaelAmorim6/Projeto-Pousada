﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pousada.Model;
using Pousada.View;
using Pousada.Controller;
namespace Pousada
{
    static class MainClass
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new TelaLogin());
            TelaLogin login = new TelaLogin();
            login.ShowDialog();

            

        }
    }
}
